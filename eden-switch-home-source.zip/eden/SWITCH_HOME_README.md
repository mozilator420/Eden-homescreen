# Switch-style home screen for the uploaded Eden source

This package contains modified source code, not a compiled Windows executable.

The desktop Qt frontend starts on a dark home screen with a horizontal game-art
carousel, a clock, the selected user's name, and an action row. It reads the same
library as Eden's existing views and sends the selected file and title ID through
the existing game-launch handler. Your existing games, settings and user profiles
are reused.

## Using the home screen

- Select a tile with the mouse or Left/Right. Double-click, choose Start, or press
  Enter to launch it.
- With a configured controller, the D-pad/left stick selects tiles, A starts the
  selected game, Down enters the shortcut row, and Up/B returns to the games.
  Up from the games selects the user/profile button; Down returns to the games.
  This follows Eden's existing controller mappings. Controller navigation must
  be enabled in Controls > Advanced (enabled by default in this source).
- Add Games opens Eden's existing game-directory picker.
- Library returns to the original game list. Turn on **View > Switch-style Home
  Screen** to return; this choice is saved between launches.
- Album opens the existing screenshot folder in the desktop file manager.
- Controllers opens the Controls group of Eden's configuration dialog.
- Settings opens Eden's configuration dialog. The user button opens Profiles.
- Sleep minimises Eden. It does not put Windows or the emulated console to sleep.

In single-window mode the home screen hides during gameplay and returns when the
game stops. In separate-window mode it remains visible with launching disabled
while a game is running. Refreshing the library preserves the selected file when
it is still present. Favorites do not create duplicate home-screen tiles.

The interface is drawn using Qt and original vector icons. It does not boot
Nintendo's HOME Menu, implement eShop/News, or change emulator compatibility.
The preview uses invented demo titles; your actual library supplies its own
game titles and icons.

## Build in Visual Studio on Windows

Use this tree as the source for a fresh Eden build. A normal installed Eden
executable cannot load these C++ source files as a skin.

The supplied root CMakeLists.txt requires **CMake 3.31 or newer**. Follow the
existing `docs/Build.md` instructions for compiler and dependency setup. Its
Visual Studio section uses clang-cl and Ninja; install C++ development tools,
Clang tools, and CMake support through the Visual Studio Installer. Then open
the extracted `eden` folder/CMake project in Visual Studio and build the `yuzu`
target, which produces `eden.exe`.

With an already configured Windows build environment, the equivalent commands
from a Developer PowerShell/Native Tools prompt are:

```powershell
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=clang-cl -DCMAKE_CXX_COMPILER=clang-cl
cmake --build build --target yuzu --parallel
```

The project may need to download dependencies during configuration. Refer to
the existing build guide for any platform-specific requirements.

## UI preview and checks without building the emulator

`tools/home-screen-preview` builds the actual new home-screen widget separately,
using only Qt 6 Widgets and Qt Test. It contains a demo app and automated checks.
The demo buttons are visual examples; emulator actions are connected only in the
full Eden frontend.

```sh
cmake -S tools/home-screen-preview -B home-preview-build -DCMAKE_PREFIX_PATH="<your Qt 6 installation>"
cmake --build home-preview-build --config Release
ctest --test-dir home-preview-build -C Release --output-on-failure
```

Run `home-preview` (or `Release/home-preview.exe` on Windows) to inspect the UI.
Passing an image filename saves a screenshot and exits. Optional width and height
arguments follow the filename. This preview does not emulate or launch a game.

Validation performed here: the widget and demo compiled with GCC 13 / Qt 6.4.2;
automated checks passed for empty, flat and nested libraries, duplicate favorites,
title fallback, selection restoration, launch path/title ID, keyboard navigation,
scanning guards, controller-to-key routing, and modal/hidden guards. The rendered
Qt widget was visually reviewed.

The complete emulator and Windows executable have not been built or run here.
The MainWindow/configuration integration therefore still needs verification in a
full build, including an actual game launch/stop and physical controller use.
