# User Handbook

The "FAQ".

This handbook is primarily aimed at the end-user - baking useful knowledge for enhancing their emulation experience.

A copy of this handbook is [available online](https://git.eden-emu.dev/eden-emu/eden/src/branch/master/docs/user/README.md).

## Basics

- **[The Basics](Basics.md)**
- **[Quickstart](./QuickStart.md)**
    - **[Windows](./QuickStart.md#windows)**
    - **[Steamdeck](./QuickStart.md#steamdeck)**
    - **[macOS](./QuickStart.md#macos)**
- **[Settings](./Settings.md)**
- **[Controllers](./Controllers.md)**
    - **[Controller profiles](./Controllers.md#configuring-controller-profiles)**
- **[Audio](Audio.md)**
- **[Graphics](Graphics.md)**
- **[Installing Mods](./Mods.md)**
- **[Data, Savefiles and Storage](Storage.md)**
- **[Orphaned Profiles](Orphaned.md)**
- **[Troubleshooting](./Troubleshoot.md)**
- **[Using Amiibo](./UsingAmiibo.md)**
- **[Using Cheats](./UsingCheats.md)**
- **[Importing Saves](./ImportingSaves.md)**
- **[Installing Atmosphere Mods](./InstallingAtmosphereMods.md)**
- **[Installing Updates & DLCs](./InstallingUpdatesDLC.md)**
- **[Multiplayer](./Multiplayer.md)**

## 3rd-party Integration

- **[Configuring Steam ROM Manager](./SteamROM.md)**
- **[Server hosting](./ServerHosting.md)**
- **[Syncthing Guide](./SyncthingGuide.md)**
- **[Third Party](./ThirdParty.md)**
    - **[Obtainium](./ThirdParty.md#configuring-obtainium)**
    - **[ES-DE](./ThirdParty.md#configuring-es-de)**
    - **[Mirrors](./ThirdParty.md#mirrors)**
    - **[GameMode](./ThirdParty.md#configuring-gamemode)**

## Advanced

- **[Command Line](./CommandLine.md)**
- **[Custom Firmware](./CFW.md)**
- **[Alter Date & Time](./AlterDateTime.md)**
- **[How To Access Logs](./HowToAccessLogs.md)**
- **[Gyro Controls](./GyroControls.md)**
- **[Platforms and Architectures](./Architectures.md)**
- **[Native Application Development](./Native.md)**
- **[Testing](./Testing.md)**
